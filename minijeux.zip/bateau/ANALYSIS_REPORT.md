# Analyse : bateau.dll

## 📋 Informations générales

| Propriété | Valeur |
|-----------|--------|
| **Type** | Delphi TForm (VCL) - PE32 DLL |
| **Nom formulaire** | Tmain |
| **Dimensions** | 640 × 400 pixels |
| **Couleur fond** | clBtnFace (#C0C0C0) |
| **Position** | poScreenCenter |

## 🎮 Description du jeu

**Bateau** est un jeu de **Drag & Drop culturel** où le joueur doit placer des souvenirs/objets typiques de différents pays européens dans les bonnes caisses d'un cargo avant la fin du chronomètre.

### Règles (extraites du DLL via radare2)
- Le capitaine (en haut à gauche) donne les instructions via une bulle de texte
- 8 objets à placer dans les bonnes caisses de pays
- **Timer initial** : 45 secondes (valeur extraite @ 0x441004)
- **Victoire** : tous les objets correctement placés → affichage "GAGNE"
- **Défaite** : temps écoulé sans tous les objets placés → affichage "PERDU"

---

## 🔧 Reverse Engineering (radare2)

### API VN-Studio

| Import | DLL | Description |
|--------|-----|-------------|
| InitVNCommandMessage | vndllapi.dll | Initialise le message window pour communiquer avec VN-Studio |

### Fonctions exportées

| Fonction | Adresse | Description |
|----------|---------|-------------|
| VNCreateDLLWindow | 0x0044192c | Crée la fenêtre du jeu |
| VNDestroyDLLWindow | 0x004419e8 | Détruit la fenêtre |

### Commandes VN-Studio extraites

| Commande | Adresse | Contexte |
|----------|---------|----------|
| `playcmd playwav music2.wav 2` | 0x00440fdc | Musique de fond au démarrage |
| `playcmd closewav` | 0x00440fc8 | Fermeture audio à la fin |
| `playcmd scene 22` | 0x00441738 | **VICTOIRE** - Transition scène |
| `playcmd scene 21` | 0x0044174c | **DÉFAITE** - Transition scène |

### Timer Logic (@ 0x441628)

```assembly
; Timer1Timer handler
0x00441647  mov eax, [edx + 0xc]    ; Récupère état timer
0x00441666  dec eax                  ; Décrémente chrono
0x0044168a  mov edx, 0x441734       ; Compare à "0"
0x0044168f  call 0x403bb4           ; StrComp
0x00441694  jne 0x441701            ; Si != 0, continue
0x00441698  call 0x441760           ; Sinon, fin de jeu
```

### Win Condition Logic (@ 0x441760)

La fonction vérifie que chaque objet est dans la bonne zone :
- Bus (1) → Angleterre
- Violon (2) ou Chap_1 (3) → Autriche
- Chap_1 (3) ou Violon (2) → Autriche  
- Chap_2 (4) → Pays-Bas (corrigé: mappé à index 7 dans le code)
- Sculpt (5) ou Art (6) → Belgique
- Art (6) ou Sculpt (5) → Belgique
- Bouteille (7) → Italie
- Cheval (8) → Grèce

### Délais

| Valeur | Hex | Utilisation |
|--------|-----|-------------|
| 1000ms | 0x3E8 | Intervalle timer normal |
| 3000ms | 0xBB8 | Délai avant envoi commande fin |

---

## 🖼️ Images extraites

| Image | Fichier | Dimensions | Description |
|-------|---------|------------|-------------|
| 1 | Image_1.png | 640×400 | Fond (cargo avec caisses de pays) |
| 2 | Image_2.png | 43×85 | Manneken Pis → Belgique |
| 3 | Image_3.png | 118×46 | Violon → Autriche |
| 4 | Image_4.png | 59×82 | Bouteille Chianti → Italie |
| 5 | Image_5.png | 88×71 | Chapeau marron → Pays-Bas |
| 6 | Image_6.png | 71×78 | Cheval de Troie → Grèce |
| 7 | Image_7.png | 51×68 | Chapeau tyrolien → Autriche |
| 8 | Image_8.png | 68×77 | Atomium → Belgique |
| 9 | Image_9.png | 100×61 | Bus rouge → Angleterre |
| 10 | Image_10.png | 149×70 | Bulle de texte capitaine |

**Transparence appliquée** : Magenta (#FF00FF) + Blanc (#FFFFFF)

---

## 📍 Zones de dépôt (TShape)

| Zone | Pays | Left | Top | Width | Height |
|------|------|------|-----|-------|--------|
| Sh_Belg_1 | Belgique | 124 | 188 | 69 | 77 |
| Sh_Belg_2 | Belgique | 40 | 144 | 145 | 121 |
| Sh_Aut_1 | Autriche | 120 | 272 | 49 | 125 |
| Sh_Aut_2 | Autriche | 48 | 272 | 121 | 121 |
| Sh_Ang | Angleterre | 356 | 60 | 133 | 101 |
| Sh_Gre | Grèce | 488 | 160 | 73 | 105 |
| Sh_pays | Pays-Bas | 360 | 168 | 121 | 113 |
| Sh_Ita | Italie | 184 | 240 | 119 | 113 |

---

## 🎯 Objets déplaçables (TImage1)

| Objet | Image | Cible | Left initial | Top initial |
|-------|-------|-------|--------------|-------------|
| Im_sculture | Image_2 | Belgique | 0 | 302 |
| Im_violon | Image_3 | Autriche | 192 | 342 |
| Im_bouteille | Image_4 | Italie | 335 | 309 |
| Im_chap_2 | Image_5 | Pays-Bas | 425 | 284 |
| Im_cheval | Image_6 | Grèce | 568 | 111 |
| Im_chap_1 | Image_7 | Autriche | 296 | 80 |
| Im_art | Image_8 | Belgique | 223 | 44 |
| Im_bus | Image_9 | Angleterre | 306 | 240 |

---

## 🏷️ Solution de correspondance

| Pays | Objet(s) |
|------|----------|
| 🇧🇪 **Belgique** | Manneken Pis (sculpt) + Atomium (art) |
| 🇦🇹 **Autriche** | Violon + Chapeau tyrolien (chap_1) |
| 🇬🇧 **Angleterre** | Bus rouge |
| 🇮🇹 **Italie** | Bouteille Chianti |
| 🇬🇷 **Grèce** | Cheval de Troie |
| 🇳🇱 **Pays-Bas** | Chapeau marron (chap_2) |

---

## 🎨 Éléments UI

### Labels de résultat

| Label | Texte | Position | Police | Couleur |
|-------|-------|----------|--------|---------|
| Perdu | "PERDU" | 200, 142 | MS Sans Serif -64 Bold | clBlue (#0000FF) |
| Gagne | "GAGNE" | 192, 150 | MS Sans Serif -64 Bold | clRed (#FF0000) |

### Chronomètre

| Élément | Position | Dimensions | Style |
|---------|----------|------------|-------|
| chrono (TPanel) | 110, 48 | 43×33 | Fond blanc, Comic Sans MS 24pt Bold, rouge |
| Valeur initiale | - | - | **45** (extrait @ 0x441004) |

---

## 📁 Fichiers de sortie

```
bateau/
├── Image_1.png       # Fond (cargo)
├── Image_2.png       # Manneken Pis (transparent: magenta+blanc)
├── Image_3.png       # Violon
├── Image_4.png       # Bouteille Chianti
├── Image_5.png       # Chapeau Pays-Bas
├── Image_6.png       # Cheval de Troie
├── Image_7.png       # Chapeau Tyrolien
├── Image_8.png       # Atomium
├── Image_9.png       # Bus Rouge
├── Image_10.png      # Bulle de texte
├── bateau-game.html  # Jeu HTML complet
└── ANALYSIS_REPORT.md
```

---

## ✅ Fonctionnalités implémentées

- [x] Drag & Drop tactile et souris
- [x] Positions initiales exactes des objets (DFM)
- [x] Zones de dépôt invisibles fidèles au DFM
- [x] Timer décroissant 45 secondes (extrait DLL)
- [x] Validation des placements (centre de l'objet dans la zone)
- [x] Messages GAGNE/PERDU aux positions exactes
- [x] Support des pays à objets multiples (Belgique, Autriche)
- [x] Commandes VN-Studio correctes (extraites du DLL)
- [x] Délai 3 secondes avant transition (0xBB8)
- [x] Transparence blanc + magenta sur les sprites
- [x] API window.bateauGame pour intégration
